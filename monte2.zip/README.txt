Montemontel Ultimate V2 — Full System (cats + adoptions admin)
--------------------------------------------------------------

Contents:
- public/ (static site: index.html, add-cat.html, admin.html, adoptions.html, etc.)
- server.js (Express backend)
- config.js (DB credentials)
- package.json
- database.sql (create database, cats + adoptions tables + sample rows)
- public/uploads (sample images)

Quick setup (XAMPP + Node.js)
1. Ensure MySQL is running (XAMPP) and import database.sql into your MySQL server:
   - phpMyAdmin -> Import -> choose database.sql -> Go
   - This creates database 'montemontel', tables 'cats' and 'adoptions', and sample rows.

2. Update config.js if your DB credentials differ or set env vars DB_HOST, DB_USER, DB_PASS, DB_NAME.

3. Install Node dependencies:
   $ npm install

4. Start the server:
   $ node server.js
   The server serves the site at http://localhost:3000 by default.

Admin pages:
- /admin.html      Manage cats (edit/delete)
- /adoptions.html  View & manage adoption requests
- /edit-adoption.html Edit a single adoption request

Notes:
- Image uploads save to public/uploads and image_url stores '/uploads/<filename>'
- This is a demo for local use. Add authentication before exposing admin pages to the public.

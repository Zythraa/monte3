-- Montemontel Ultimate V2 (cats + adoptions)
CREATE DATABASE IF NOT EXISTS montemontel;
USE montemontel;

CREATE TABLE IF NOT EXISTS cats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  age INT NULL,
  breed VARCHAR(150) NULL,
  description TEXT NULL,
  image_url VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS adoptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cat_id INT NOT NULL,
  adopter_name VARCHAR(150) NOT NULL,
  adopter_email VARCHAR(150) NOT NULL,
  message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cat_id) REFERENCES cats(id) ON DELETE CASCADE
);

-- Sample cats
INSERT INTO cats (name, age, breed, description, image_url) VALUES
('Mochi', 2, 'Domestic Shorthair', 'Playful and affectionate', '/uploads/cat1.png'),
('Luna', 4, 'Siamese mix', 'Calm and curious', '/uploads/cat2.png');

-- Sample adoption
INSERT INTO adoptions (cat_id, adopter_name, adopter_email, message) VALUES
(1, 'Alice Example', 'alice@example.com', 'I have a quiet home and would love to adopt Mochi.');

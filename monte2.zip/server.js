/**
 * Express server with MySQL CRUD for cats and adoptions, image upload with multer.
 * Update config.js with DB credentials.
 */
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mysql = require('mysql2/promise');
const config = require('./config');

const app = express();
const PORT = process.env.PORT || 3000;

const uploadDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const n = Date.now() + '-' + Math.random().toString(36).slice(2,8) + path.extname(file.originalname || '.png');
    cb(null, n);
  }
});
const upload = multer({ storage });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const pool = mysql.createPool({
  host: config.DB_HOST,
  user: config.DB_USER,
  password: config.DB_PASS,
  database: config.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10
});

// Cats APIs
app.get('/api/cats', async (req, res) => {
  try{
    const [rows] = await pool.query('SELECT id, name, age, breed, description, image_url FROM cats ORDER BY id DESC');
    res.json(rows);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.get('/api/cats/:id', async (req, res)=>{
  try{
    const [rows] = await pool.query('SELECT id, name, age, breed, description, image_url FROM cats WHERE id=?', [req.params.id]);
    if(!rows.length) return res.status(404).json({error:'not found'});
    res.json(rows[0]);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.post('/api/cats', upload.single('image'), async (req, res)=>{
  try{
    const { name, age, breed, description } = req.body;
    const errors = [];
    if(!name || !name.trim()) errors.push('name required');
    if(age && isNaN(Number(age))) errors.push('age must be a number');
    if(errors.length) return res.status(400).json({ errors });
    const image_url = req.file ? '/uploads/' + req.file.filename : null;
    const [result] = await pool.query('INSERT INTO cats (name, age, breed, description, image_url) VALUES (?,?,?,?,?)',
      [name.trim(), age || null, breed || null, description || null, image_url]);
    res.status(201).json({ id: result.insertId, message: 'created' });
  }catch(err){ console.error(err); res.status(500).json({ error: 'server error' }); }
});

app.put('/api/cats/:id', upload.single('image'), async (req, res)=>{
  try{
    const id = req.params.id;
    const { name, age, breed, description } = req.body;
    const [rows] = await pool.query('SELECT image_url FROM cats WHERE id=?', [id]);
    if(!rows.length) return res.status(404).json({ error: 'not found' });
    let image_url = rows[0].image_url;
    if(req.file){
      if(image_url){
        try{ fs.unlinkSync(path.join(__dirname, 'public', image_url)); }catch(e){}
      }
      image_url = '/uploads/' + req.file.filename;
    }
    await pool.query('UPDATE cats SET name=?, age=?, breed=?, description=?, image_url=? WHERE id=?',
      [name, age || null, breed || null, description || null, image_url, id]);
    res.json({ message: 'updated' });
  }catch(err){ console.error(err); res.status(500).json({error:'server error'}); }
});

app.delete('/api/cats/:id', async (req, res)=>{
  try{
    const id = req.params.id;
    const [rows] = await pool.query('SELECT image_url FROM cats WHERE id=?', [id]);
    if(!rows.length) return res.status(404).json({ error:'not found' });
    const image_url = rows[0].image_url;
    await pool.query('DELETE FROM cats WHERE id=?', [id]);
    if(image_url){ try{ fs.unlinkSync(path.join(__dirname, 'public', image_url)); }catch(e){} }
    res.json({ message: 'deleted' });
  }catch(err){ console.error(err); res.status(500).json({error:'server error'}); }
});

// Adoptions APIs (full CRUD)
app.get('/api/adoptions', async (req, res)=>{
  try{
    const [rows] = await pool.query(`SELECT a.id, a.cat_id, a.adopter_name, a.adopter_email, a.message, a.created_at, c.name as cat_name
      FROM adoptions a LEFT JOIN cats c ON a.cat_id = c.id ORDER BY a.id DESC`);
    res.json(rows);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.get('/api/adoptions/:id', async (req, res)=>{
  try{
    const [rows] = await pool.query('SELECT id, cat_id, adopter_name, adopter_email, message, created_at FROM adoptions WHERE id=?', [req.params.id]);
    if(!rows.length) return res.status(404).json({error:'not found'});
    res.json(rows[0]);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.post('/api/adoptions', async (req, res)=>{
  try{
    const { cat_id, name, email, message } = req.body;
    if(!cat_id || !name || !email) return res.status(400).json({ error: 'Missing required fields' });
    await pool.query('INSERT INTO adoptions (cat_id, adopter_name, adopter_email, message) VALUES (?,?,?,?)',
      [cat_id, name, email, message || null]);
    res.json({ message: 'Adoption request saved' });
  }catch(err){ console.error(err); res.status(500).json({error:'server error'}); }
});

app.put('/api/adoptions/:id', async (req, res)=>{
  try{
    const id = req.params.id;
    const { cat_id, name, email, message } = req.body;
    const [rows] = await pool.query('SELECT id FROM adoptions WHERE id=?', [id]);
    if(!rows.length) return res.status(404).json({ error: 'not found' });
    await pool.query('UPDATE adoptions SET cat_id=?, adopter_name=?, adopter_email=?, message=? WHERE id=?',
      [cat_id, name, email, message || null, id]);
    res.json({ message: 'updated' });
  }catch(err){ console.error(err); res.status(500).json({error:'server error'}); }
});

app.delete('/api/adoptions/:id', async (req, res)=>{
  try{
    const id = req.params.id;
    await pool.query('DELETE FROM adoptions WHERE id=?', [id]);
    res.json({ message: 'deleted' });
  }catch(err){ console.error(err); res.status(500).json({error:'server error'}); }
});

app.listen(PORT, ()=>console.log('Server running on', PORT));

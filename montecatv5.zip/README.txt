MonteCat v5 - Local ZIP. Import backend/db.sql into phpMyAdmin, then run backend: npm install && node server.js

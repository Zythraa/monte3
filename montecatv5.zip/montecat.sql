-- montecat.sql
CREATE DATABASE IF NOT EXISTS montecat CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE montecat;

DROP TABLE IF EXISTS cats;
CREATE TABLE cats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  age DECIMAL(4,2) DEFAULT NULL,
  breed VARCHAR(100),
  description TEXT,
  image_url VARCHAR(255),
  status ENUM('available','adopted') DEFAULT 'available',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS adoptions;
CREATE TABLE adoptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cat_id INT NOT NULL,
  adopter_name VARCHAR(100),
  adopter_email VARCHAR(150),
  message TEXT,
  status ENUM('pending','accepted','rejected') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (cat_id) REFERENCES cats(id) ON DELETE CASCADE
);

INSERT INTO cats (name, age, breed, description, image_url, status) VALUES
('Milo', 2.00, 'Persian', 'Friendly and loves naps.', '/uploads/cat1.png', 'available'),
('Luna', 0.50, 'Siamese', 'Playful kitten, loves chasing toys.', '/uploads/cat2.png', 'available'),
('Oliver', 1.25, 'British Shorthair', 'Quiet and calm cat.', '/uploads/cat3.png', 'available');

INSERT INTO adoptions (cat_id, adopter_name, adopter_email, message, status) VALUES
(1, 'Alice Smith', 'alice@example.com', 'I love cats!', 'pending');

/**
 * MonteCat v5 - backend server (simplified admin edit)
 */
const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const mysql = require("mysql2/promise");
const bodyParser = require("body-parser");
const cors = require("cors");
const config = require("./config");

const app = express();
const PORT = process.env.PORT || 3000;

// setup uploads dir in frontend folder
const UPLOAD_DIR = path.join(__dirname, "..", "frontend", "uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) =>
    cb(
      null,
      Date.now() +
        "-" +
        Math.random().toString(36).slice(2, 8) +
        path.extname(file.originalname || ".png")
    ),
});
const upload = multer({ storage });

app.use(cors());
app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
// serve frontend static
app.use(express.static(path.join(__dirname, "..", "frontend")));

const pool = mysql.createPool({
  host: config.DB_HOST,
  user: config.DB_USER,
  password: config.DB_PASS,
  database: config.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});

// helper: fake email logger
function sendFakeEmail(to, subject, body) {
  console.log("=== FAKE EMAIL ===");
  console.log("To:", to);
  console.log("Subject:", subject);
  console.log("Body:", body);
  console.log("==================");
}

// =======================
// CATS APIs
// =======================
app.get("/api/cats", async (req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id,name,age,breed,description,image_url,status FROM cats WHERE status="available" ORDER BY id DESC'
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "db error" });
  }
});

app.get("/api/admin/cats", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT id,name,age,breed,description,image_url,status FROM cats ORDER BY id DESC"
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "db error" });
  }
});

app.get("/api/cats/:id", async (req, res) => {
  try {
    const [rows] = await pool.query("SELECT * FROM cats WHERE id=?", [
      req.params.id,
    ]);
    if (!rows.length) return res.status(404).json({ error: "not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "db error" });
  }
});

app.post("/api/cats", upload.single("image"), async (req, res) => {
  try {
    const { name, age, breed, description } = req.body;
    if (!name || !name.trim())
      return res.status(400).json({ error: "name required" });
    const image_url = req.file ? "/uploads/" + req.file.filename : null;
    const [result] = await pool.query(
      "INSERT INTO cats (name,age,breed,description,image_url,status) VALUES (?,?,?,?,?,?)",
      [name.trim(), age || null, breed || null, description || null, image_url, "available"]
    );
    res.status(201).json({ id: result.insertId, message: "created" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

app.put("/api/cats/:id", upload.single("image"), async (req, res) => {
  try {
    const id = req.params.id;
    const { name, age, breed, description, status } = req.body;
    const [rows] = await pool.query("SELECT image_url FROM cats WHERE id=?", [
      id,
    ]);
    if (!rows.length) return res.status(404).json({ error: "not found" });

    let image_url = rows[0].image_url;
    if (req.file) {
      if (image_url) {
        try {
          fs.unlinkSync(path.join(UPLOAD_DIR, path.basename(image_url)));
        } catch (e) {}
      }
      image_url = "/uploads/" + req.file.filename;
    }

    await pool.query(
      "UPDATE cats SET name=?,age=?,breed=?,description=?,image_url=?,status=? WHERE id=?",
      [name, age || null, breed || null, description || null, image_url, status || "available", id]
    );
    res.json({ message: "updated" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

app.delete("/api/cats/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const [rows] = await pool.query("SELECT image_url FROM cats WHERE id=?", [
      id,
    ]);
    if (!rows.length) return res.status(404).json({ error: "not found" });
    const image_url = rows[0].image_url;
    await pool.query("DELETE FROM cats WHERE id=?", [id]);
    if (image_url) {
      try {
        fs.unlinkSync(path.join(UPLOAD_DIR, path.basename(image_url)));
      } catch (e) {}
    }
    res.json({ message: "deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

// =======================
// ADOPTIONS APIs
// =======================
app.get("/api/adoptions", async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT a.id,a.cat_id,a.adopter_name,a.adopter_email,a.message,a.status,a.created_at,c.name AS cat_name 
       FROM adoptions a 
       LEFT JOIN cats c ON a.cat_id=c.id 
       ORDER BY a.id DESC`
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "db error" });
  }
});

// user submits adoption
app.post("/api/adoptions", async (req, res) => {
  try {
    const { cat_id, name, email, message } = req.body;
    if (!cat_id || !name || !email)
      return res.status(400).json({ error: "Missing required fields" });

    const [result] = await pool.query(
      "INSERT INTO adoptions (cat_id,adopter_name,adopter_email,message,status) VALUES (?,?,?,?,?)",
      [cat_id, name, email, message || null, "pending"]
    );

    const id = result.insertId;
    sendFakeEmail(
      email,
      "Adoption request received",
      `Hi ${name}, we received your request (ID: ${id}). You’ll be notified by email once it’s reviewed.`
    );
    sendFakeEmail(
      "admin@montecat.local",
      "New adoption request",
      `New request ID ${id} by ${name} for cat ${cat_id}.`
    );

    res.json({ id, message: "Adoption request submitted." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

// admin updates adoption STATUS only
app.put("/api/adoptions/:id/status", async (req, res) => {
  try {
    const id = req.params.id;
    const { status } = req.body;
    if (!["pending", "accepted", "rejected"].includes(status))
      return res.status(400).json({ error: "Invalid status" });

    const [rows] = await pool.query(
      "SELECT cat_id,adopter_name,adopter_email FROM adoptions WHERE id=?",
      [id]
    );
    if (!rows.length) return res.status(404).json({ error: "not found" });

    const { cat_id, adopter_name, adopter_email } = rows[0];
    await pool.query("UPDATE adoptions SET status=? WHERE id=?", [status, id]);

    // update cat availability
    const catStatus = status === "accepted" ? "adopted" : "available";
    await pool.query("UPDATE cats SET status=? WHERE id=?", [catStatus, cat_id]);

    sendFakeEmail(
      adopter_email,
      "Adoption status update",
      `Hi ${adopter_name}, your adoption request (ID: ${id}) is now: ${status.toUpperCase()}`
    );

    res.json({ message: "Adoption status updated" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

// admin edits adoption details (no need for cat_id)
app.put("/api/adoptions/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const { adopter_name, adopter_email, message, status } = req.body;
    const [rows] = await pool.query("SELECT * FROM adoptions WHERE id=?", [id]);
    if (!rows.length) return res.status(404).json({ error: "not found" });

    await pool.query(
      "UPDATE adoptions SET adopter_name=?, adopter_email=?, message=?, status=? WHERE id=?",
      [adopter_name, adopter_email, message || null, status || rows[0].status, id]
    );

    res.json({ message: "Adoption updated successfully" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

app.delete("/api/adoptions/:id", async (req, res) => {
  try {
    const id = req.params.id;
    await pool.query("DELETE FROM adoptions WHERE id=?", [id]);
    res.json({ message: "deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

// =======================
// REPORTS APIs
// =======================
app.post("/api/report", async (req, res) => {
  try {
    const { message } = req.body;
    if (!message) return res.status(400).json({ error: "message required" });
    await pool.query("INSERT INTO reports (message) VALUES (?)", [message]);
    sendFakeEmail("admin@montecat.local", "New report", `Report: ${message}`);
    res.json({ message: "Report submitted. Thank you." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server error" });
  }
});

// catch-all for unknown routes
app.use((req, res) => res.status(404).send("Not found"));

app.listen(PORT, () =>
  console.log(`🐾 MonteCat backend running at http://localhost:${PORT}`)
);
